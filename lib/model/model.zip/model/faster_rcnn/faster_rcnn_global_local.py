import random
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torchvision.models as models
from torch.autograd import Variable
import numpy as np
from model.utils.config import cfg
from model.rpn.rpn import _RPN
from model.roi_pooling.modules.roi_pool import _RoIPooling
from model.roi_crop.modules.roi_crop import _RoICrop
from model.roi_align.modules.roi_align import RoIAlignAvg
from model.rpn.proposal_target_layer_cascade import _ProposalTargetLayer
import time
import pdb
from model.utils.net_utils import _smooth_l1_loss, _crop_pool_layer, _affine_grid_gen, _affine_theta,grad_reverse

class _fasterRCNN(nn.Module):
    """ faster RCNN """
    def __init__(self, classes, class_agnostic,lc,gc):
        super(_fasterRCNN, self).__init__()
        self.classes = classes
        self.n_classes = len(classes)
        self.class_agnostic = class_agnostic
        # loss
        self.RCNN_loss_cls = 0
        self.RCNN_loss_bbox = 0
        self.lc = lc
        self.gc = gc
        # define rpn
        self.RCNN_rpn = _RPN(self.dout_base_model)
        self.RCNN_proposal_target = _ProposalTargetLayer(self.n_classes)
        self.RCNN_roi_pool = _RoIPooling(cfg.POOLING_SIZE, cfg.POOLING_SIZE, 1.0/16.0)
        self.RCNN_roi_align = RoIAlignAvg(cfg.POOLING_SIZE, cfg.POOLING_SIZE, 1.0/16.0)

        self.grid_size = cfg.POOLING_SIZE * 2 if cfg.CROP_RESIZE_WITH_MAX_POOL else cfg.POOLING_SIZE
        self.RCNN_roi_crop = _RoICrop()

    def reconstruct_loss(self,src,tgt):
        return torch.sum((src-tgt)**2) / (src.shape[0]*src.shape[1]*src.shape[2]*src.shape[3])

    def forward(self, im_data, im_info, gt_boxes, num_boxes, phase=1, target=False, eta=1.0):
        batch_size = im_data.size(0)

        im_info = im_info.data
        gt_boxes = gt_boxes.data
        num_boxes = num_boxes.data

        if phase == 1:
            base_feat1 = self.RCNN_base1(im_data)
            base_feat_di1 = self.di1(base_feat1)
            base_feat_ds1 = self.ds1(base_feat1)
            # feed image data to base model to obtain base feature map
            base_feat = self.RCNN_base2(base_feat1+base_feat_di1)
            # domain invariant
            base_feat_di = self.di(base_feat)
            # domain specific
            base_feat_ds = self.ds(base_feat)

            if target == False:
                d_pixel0, _ = self.netD_pixel(grad_reverse(base_feat1, lambd=eta))
                _, feat_pixel = self.netD_pixel(base_feat1.detach())
                d_pixel1, _ = self.netD_pixel1(grad_reverse(base_feat_ds1, lambd=eta))
                domain_p_base, _ = self.netD_base(grad_reverse(base_feat, lambd=eta))
                _,feat_base = self.netD_base(base_feat.detach())
                domain_p_ds,_ = self.netD_ds(grad_reverse(base_feat_ds,lambd=eta))
                _,feat_ds = self.netD_ds(base_feat_ds.detach())

                # feed base feature map tp RPN to obtain rois
                self.RCNN_rpn.train()
                rois, rpn_loss_cls, rpn_loss_bbox = self.RCNN_rpn(base_feat_di, im_info, gt_boxes, num_boxes)
                # if it is training phrase, then use ground trubut bboxes for refining
                if self.training:
                    roi_data = self.RCNN_proposal_target(rois, gt_boxes, num_boxes)
                    rois, rois_label, rois_target, rois_inside_ws, rois_outside_ws = roi_data

                    rois_label = Variable(rois_label.view(-1).long())
                    rois_target = Variable(rois_target.view(-1, rois_target.size(2)))
                    rois_inside_ws = Variable(rois_inside_ws.view(-1, rois_inside_ws.size(2)))
                    rois_outside_ws = Variable(rois_outside_ws.view(-1, rois_outside_ws.size(2)))
                else:
                    rois_label = None
                    rois_target = None
                    rois_inside_ws = None
                    rois_outside_ws = None
                    rpn_loss_cls = 0
                    rpn_loss_bbox = 0
                rois = Variable(rois)

                if cfg.POOLING_MODE == 'align':
                    pooled_feat_di = self.RCNN_roi_align(base_feat_di, rois.view(-1, 5))
                    pooled_feat = self.RCNN_roi_align(base_feat, rois.detach().view(-1, 5))

                pool_feat_list = [pooled_feat_di, pooled_feat]
                cls_prob_list = []
                bbox_pred_list = []
                RCNN_loss_cls_list = []
                RCNN_loss_bbox_list = []

                pooled_elem = pooled_feat_di
                pooled_feat_di_out = self._head_to_tail_di(pooled_elem)

                if self.lc:
                    feat_pixel_di = feat_pixel.view(1, -1).repeat(pooled_feat_di_out.size(0), 1)
                    pooled_feat_di_out = torch.cat((feat_pixel_di, pooled_feat_di_out), 1)
                if self.gc:
                    feat = feat_ds
                    feat_n = feat.view(1, -1).repeat(pooled_feat_di_out.size(0), 1)
                    pooled_feat_di_out = torch.cat((feat_n, pooled_feat_di_out), 1)
                bbox_pred_di = self.RCNN_bbox_pred_di(pooled_feat_di_out)
                if self.training and not self.class_agnostic:
                    bbox_pred_view = bbox_pred_di.view(bbox_pred_di.size(0), int(bbox_pred_di.size(1) / 4), 4)
                    bbox_pred_select = torch.gather(bbox_pred_view, 1, rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1, 4))
                    bbox_pred_di = bbox_pred_select.squeeze(1)

                cls_score_di = self.RCNN_cls_score_di(pooled_feat_di_out)
                cls_prob_di = F.softmax(cls_score_di, 1)

                RCNN_loss_cls_di = 0
                RCNN_loss_bbox_di = 0
                if self.training:
                    RCNN_loss_cls_di = F.cross_entropy(cls_score_di, rois_label)
                    RCNN_loss_bbox_di = _smooth_l1_loss(bbox_pred_di, rois_target, rois_inside_ws, rois_outside_ws)
                cls_prob_di = cls_prob_di.view(batch_size, rois.size(1), -1)
                bbox_pred_di = bbox_pred_di.view(batch_size, rois.size(1), -1)

                pooled_elem = pooled_feat
                pooled_feat_base_out = self._head_to_tail_base(pooled_elem)
                if self.lc:
                    feat_pixel_base = feat_pixel.view(1, -1).repeat(pooled_feat_base_out.size(0), 1)
                    pooled_feat_base_out = torch.cat((feat_pixel_base, pooled_feat_base_out), 1)
                if self.gc:
                    feat = feat_base
                    feat_n = feat.view(1, -1).repeat(pooled_feat_base_out.size(0), 1)
                    pooled_feat_base_out = torch.cat((feat_n, pooled_feat_base_out), 1)
                bbox_pred_base = self.RCNN_bbox_pred_base(pooled_feat_base_out)
                if self.training and not self.class_agnostic:
                    bbox_pred_view = bbox_pred_base.view(bbox_pred_base.size(0), int(bbox_pred_base.size(1) / 4), 4)
                    bbox_pred_select = torch.gather(bbox_pred_view, 1, rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1, 4))
                    bbox_pred_base = bbox_pred_select.squeeze(1)
                cls_score_base = self.RCNN_cls_score_base(pooled_feat_base_out)
                cls_prob_base = F.softmax(cls_score_base, 1)

                RCNN_loss_cls_base = 0
                RCNN_loss_bbox_base = 0
                if self.training:
                    RCNN_loss_cls_base = F.cross_entropy(cls_score_base, rois_label)
                    RCNN_loss_bbox_base = _smooth_l1_loss(bbox_pred_base, rois_target, rois_inside_ws, rois_outside_ws)
                cls_prob_base = cls_prob_base.view(batch_size, rois.size(1), -1)
                bbox_pred_base = bbox_pred_base.view(batch_size, rois.size(1), -1)

                cls_prob_list.append(cls_prob_di)
                bbox_pred_list.append(bbox_pred_di)
                RCNN_loss_cls_list.append(RCNN_loss_cls_di)
                RCNN_loss_bbox_list.append(RCNN_loss_bbox_di)

                cls_prob_list.append(cls_prob_base)
                bbox_pred_list.append(bbox_pred_base)
                RCNN_loss_cls_list.append(RCNN_loss_cls_base)
                RCNN_loss_bbox_list.append(RCNN_loss_bbox_base)

                d_pixel = [d_pixel0, d_pixel1]
                return rois, cls_prob_list, bbox_pred_list, rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls_list, RCNN_loss_bbox_list, rois_label, d_pixel, domain_p_base, domain_p_ds
            else:
                d_pixel0, _ = self.netD_pixel(grad_reverse(base_feat1, lambd=eta))
                d_pixel1, _ = self.netD_pixel1(grad_reverse(base_feat_ds1, lambd=eta))
                domain_p_base, _ = self.netD_base(grad_reverse(base_feat, lambd=eta))
                domain_p_ds, _ = self.netD_ds(grad_reverse(base_feat_ds, lambd=eta))
                d_pixel = [d_pixel0, d_pixel1]
                return d_pixel, domain_p_base, domain_p_ds
        elif phase == 2:
            base_feat1 = self.RCNN_base1(im_data)
            base_feat_di1 = self.di1(base_feat1)
            base_feat_ds1 = self.ds1(base_feat1)
            # feed image data to base model to obtain base feature map
            base_feat = self.RCNN_base2(base_feat1+base_feat_di1)
            # domain invariant
            base_feat_di = self.di(base_feat)
            # domain specific
            base_feat_ds = self.ds(base_feat)

            if target == False:
                d_pixel, _ = self.netD_pixel1(grad_reverse(base_feat_ds1, lambd=eta))
                _, feat_pixel = self.netD_pixel(base_feat1.detach())
                domain_p_ds,_ = self.netD_ds(grad_reverse(base_feat_ds,lambd=eta))
                _,feat_ds = self.netD_ds(base_feat_ds.detach())
                self.RCNN_rpn.train()
                rois, rpn_loss_cls, rpn_loss_bbox = self.RCNN_rpn(base_feat_di, im_info, gt_boxes, num_boxes)

                # if it is training phrase, then use ground trubut bboxes for refining
                if self.training:
                    roi_data = self.RCNN_proposal_target(rois, gt_boxes, num_boxes)
                    rois, rois_label, rois_target, rois_inside_ws, rois_outside_ws = roi_data

                    rois_label = Variable(rois_label.view(-1).long())
                    rois_target = Variable(rois_target.view(-1, rois_target.size(2)))
                    rois_inside_ws = Variable(rois_inside_ws.view(-1, rois_inside_ws.size(2)))
                    rois_outside_ws = Variable(rois_outside_ws.view(-1, rois_outside_ws.size(2)))
                else:
                    rois_label = None
                    rois_target = None
                    rois_inside_ws = None
                    rois_outside_ws = None
                    rpn_loss_cls = 0
                    rpn_loss_bbox = 0
                rois = Variable(rois)

                if cfg.POOLING_MODE == 'align':
                    pooled_feat_di = self.RCNN_roi_align(base_feat_di, rois.view(-1, 5))
                    pooled_feat_ds = self.RCNN_roi_align(base_feat_ds, rois.detach().view(-1, 5))
                    pooled_feat = self.RCNN_roi_align(base_feat, rois.detach().view(-1, 5))
                    pooled_feat_di1 = self.RCNN_roi_align(base_feat_di1, rois.detach().view(-1, 5))
                    pooled_feat_ds1 = self.RCNN_roi_align(base_feat_ds1, rois.detach().view(-1, 5))

                di_pool = F.avg_pool2d(pooled_feat_di, (7,7))[:,:,0,0]
                di_pool = F.normalize(di_pool, dim=1)
                di_adjacency = torch.matmul(di_pool, di_pool.permute(1,0))
                di_adjacency = F.softmax(di_adjacency, dim=1)
                base_pool = F.avg_pool2d(pooled_feat, (7,7))[:,:,0,0]
                base_pool = F.normalize(base_pool, dim=1)
                base_adjacency = torch.matmul(base_pool, base_pool.permute(1,0))
                base_adjacency = F.softmax(base_adjacency, dim=1)
                adj_loss = torch.mean(torch.abs(di_adjacency - base_adjacency))

                #Mutual Information
                Mutual_invariant = F.avg_pool2d(pooled_feat_di, (7, 7))[:,:,0,0]
                Mutual_specific = F.avg_pool2d(pooled_feat_ds, (7, 7))[:,:,0,0]
                Mutual_invariant_shuffle = torch.index_select(Mutual_invariant, 0, Variable(torch.randperm(Mutual_invariant.shape[0]).cuda()))
                MI_loss = self.mutual_information_estimator(Mutual_specific, Mutual_invariant, Mutual_invariant_shuffle) * 0.0001
                MI_loss0 = -1.0 * MI_loss

                #Mutual Information
                Mutual_invariant1 = F.avg_pool2d(pooled_feat_di1, (7, 7))[:,:,0,0]
                Mutual_specific1 = F.avg_pool2d(pooled_feat_ds1, (7, 7))[:,:,0,0]
                Mutual_invariant_shuffle1 = torch.index_select(Mutual_invariant1, 0, Variable(torch.randperm(Mutual_invariant1.shape[0]).cuda()))
                MI_loss1 = self.mutual_information_estimator1(Mutual_specific1, Mutual_invariant1, Mutual_invariant_shuffle1) * 0.0001
                MI_loss1 = -1.0 * MI_loss1

                MI_loss = [MI_loss0, MI_loss1]

                cls_prob_list = []
                bbox_pred_list = []
                RCNN_loss_cls_list = []
                RCNN_loss_bbox_list = []

                pooled_elem = pooled_feat_di
                pooled_feat_di_out = self._head_to_tail_di(pooled_elem)

                if self.lc:
                    feat_pixel_di = feat_pixel.view(1, -1).repeat(pooled_feat_di_out.size(0), 1)
                    pooled_feat_di_out = torch.cat((feat_pixel_di, pooled_feat_di_out), 1)
                if self.gc:
                    feat = feat_ds
                    feat_n = feat.view(1, -1).repeat(pooled_feat_di_out.size(0), 1)
                    pooled_feat_di_out = torch.cat((feat_n, pooled_feat_di_out), 1)
                bbox_pred_di = self.RCNN_bbox_pred_di(pooled_feat_di_out)
                if self.training and not self.class_agnostic:
                    bbox_pred_view = bbox_pred_di.view(bbox_pred_di.size(0), int(bbox_pred_di.size(1) / 4), 4)
                    bbox_pred_select = torch.gather(bbox_pred_view, 1, rois_label.view(rois_label.size(0), 1, 1).expand(rois_label.size(0), 1, 4))
                    bbox_pred_di = bbox_pred_select.squeeze(1)

                cls_score_di = self.RCNN_cls_score_di(pooled_feat_di_out)
                cls_prob_di = F.softmax(cls_score_di, 1)

                RCNN_loss_cls_di = 0
                RCNN_loss_bbox_di = 0
                if self.training:
                    RCNN_loss_cls_di = F.cross_entropy(cls_score_di, rois_label)
                    RCNN_loss_bbox_di = _smooth_l1_loss(bbox_pred_di, rois_target, rois_inside_ws, rois_outside_ws)
                cls_prob_di = cls_prob_di.view(batch_size, rois.size(1), -1)
                bbox_pred_di = bbox_pred_di.view(batch_size, rois.size(1), -1)

                cls_prob_list.append(cls_prob_di)
                bbox_pred_list.append(bbox_pred_di)
                RCNN_loss_cls_list.append(RCNN_loss_cls_di)
                RCNN_loss_bbox_list.append(RCNN_loss_bbox_di)

                return rois, cls_prob_list, bbox_pred_list, rpn_loss_cls, rpn_loss_bbox, RCNN_loss_cls_list, RCNN_loss_bbox_list, rois_label, domain_p_ds, d_pixel, MI_loss, adj_loss
            else:
                d_pixel, _ = self.netD_pixel1(grad_reverse(base_feat_ds1, lambd=eta))
                domain_p_ds,_ = self.netD_ds(grad_reverse(base_feat_ds,lambd=eta))
                self.RCNN_rpn.eval()
                rois, rpn_loss_cls, rpn_loss_bbox = self.RCNN_rpn(base_feat_di, im_info, gt_boxes, num_boxes)
                if self.training:
                    roi_data = self.RCNN_proposal_target(rois, gt_boxes, num_boxes)
                    rois, rois_label, rois_target, rois_inside_ws, rois_outside_ws = roi_data

                    rois_label = Variable(rois_label.view(-1).long())
                    rois_target = Variable(rois_target.view(-1, rois_target.size(2)))
                    rois_inside_ws = Variable(rois_inside_ws.view(-1, rois_inside_ws.size(2)))
                    rois_outside_ws = Variable(rois_outside_ws.view(-1, rois_outside_ws.size(2)))
                else:
                    rois_label = None
                    rois_target = None
                    rois_inside_ws = None
                    rois_outside_ws = None
                    rpn_loss_cls = 0
                    rpn_loss_bbox = 0
                rois = Variable(rois)

                if cfg.POOLING_MODE == 'align':
                    pooled_feat_di = self.RCNN_roi_align(base_feat_di, rois.view(-1, 5))
                    pooled_feat_ds = self.RCNN_roi_align(base_feat_ds, rois.view(-1, 5))
                    pooled_feat = self.RCNN_roi_align(base_feat, rois.detach().view(-1, 5))
                    pooled_feat_di1 = self.RCNN_roi_align(base_feat_di1, rois.detach().view(-1, 5))
                    pooled_feat_ds1 = self.RCNN_roi_align(base_feat_ds1, rois.detach().view(-1, 5))

                di_pool = F.avg_pool2d(pooled_feat_di, (7,7))[:,:,0,0]
                di_pool = F.normalize(di_pool, dim=1)
                di_adjacency = torch.matmul(di_pool, di_pool.permute(1,0))
                di_adjacency = F.softmax(di_adjacency, dim=1)
                base_pool = F.avg_pool2d(pooled_feat, (7,7))[:,:,0,0]
                base_pool = F.normalize(base_pool, dim=1)
                base_adjacency = torch.matmul(base_pool, base_pool.permute(1,0))
                base_adjacency = F.softmax(base_adjacency, dim=1)
                adj_loss = torch.mean(torch.abs(di_adjacency - base_adjacency))

                #Mutual Information
                Mutual_invariant = F.avg_pool2d(pooled_feat_di, (7, 7))[:,:,0,0]
                Mutual_specific = F.avg_pool2d(pooled_feat_ds, (7, 7))[:,:,0,0]
                Mutual_invariant_shuffle = torch.index_select(Mutual_invariant, 0, Variable(torch.randperm(Mutual_invariant.shape[0]).cuda()))
                MI_loss = self.mutual_information_estimator(Mutual_specific, Mutual_invariant, Mutual_invariant_shuffle) * 0.0001
                MI_loss0 = -1.0 * MI_loss

                #Mutual Information
                Mutual_invariant1 = F.avg_pool2d(pooled_feat_di1, (7, 7))[:,:,0,0]
                Mutual_specific1 = F.avg_pool2d(pooled_feat_ds1, (7, 7))[:,:,0,0]
                Mutual_invariant_shuffle1 = torch.index_select(Mutual_invariant1, 0, Variable(torch.randperm(Mutual_invariant1.shape[0]).cuda()))
                MI_loss1 = self.mutual_information_estimator1(Mutual_specific1, Mutual_invariant1, Mutual_invariant_shuffle1) * 0.0001
                MI_loss1 = -1.0 * MI_loss1

                MI_loss = [MI_loss0, MI_loss1]
                return domain_p_ds, d_pixel, MI_loss, adj_loss
        elif phase == 3:
            base_feat1 = self.RCNN_base1(im_data)
            base_feat_di1 = self.di1(base_feat1)
            base_feat_ds1 = self.ds1(base_feat1)
            # feed image data to base model to obtain base feature map
            base_feat = self.RCNN_base2(base_feat1+base_feat_di1)
            # domain invariant
            base_feat_di = self.di(base_feat)
            # domain specific
            base_feat_ds = self.ds(base_feat)

            if target == False:
                self.RCNN_rpn.train()
                rois, rpn_loss_cls, rpn_loss_bbox = self.RCNN_rpn(base_feat_di, im_info, gt_boxes, num_boxes)

                if self.training:
                    roi_data = self.RCNN_proposal_target(rois, gt_boxes, num_boxes)
                    rois, rois_label, rois_target, rois_inside_ws, rois_outside_ws = roi_data

                    rois_label = Variable(rois_label.view(-1).long())
                    rois_target = Variable(rois_target.view(-1, rois_target.size(2)))
                    rois_inside_ws = Variable(rois_inside_ws.view(-1, rois_inside_ws.size(2)))
                    rois_outside_ws = Variable(rois_outside_ws.view(-1, rois_outside_ws.size(2)))
                else:
                    rois_label = None
                    rois_target = None
                    rois_inside_ws = None
                    rois_outside_ws = None
                    rpn_loss_cls = 0
                    rpn_loss_bbox = 0
                rois = Variable(rois)

                if cfg.POOLING_MODE == 'align':
                    pooled_feat_di = self.RCNN_roi_align(base_feat_di, rois.view(-1, 5))
                    pooled_feat = self.RCNN_roi_align(base_feat, rois.detach().view(-1, 5))
                    pooled_feat_ds = self.RCNN_roi_align(base_feat_ds, rois.detach().view(-1, 5))

                pooled_feat_ds_mean = pooled_feat_ds
                cat_reps = torch.cat((pooled_feat_di, pooled_feat_ds_mean), 1)
                pooled_mean = self.recon(cat_reps)
                recon_loss = self.reconstruct_loss(pooled_mean, pooled_feat.detach())

                return recon_loss
            else:
                self.RCNN_rpn.eval()
                rois, rpn_loss_cls, rpn_loss_bbox = self.RCNN_rpn(base_feat_di, im_info, gt_boxes, num_boxes)
                if self.training:
                    roi_data = self.RCNN_proposal_target(rois, gt_boxes, num_boxes)
                    rois, rois_label, rois_target, rois_inside_ws, rois_outside_ws = roi_data

                    rois_label = Variable(rois_label.view(-1).long())
                    rois_target = Variable(rois_target.view(-1, rois_target.size(2)))
                    rois_inside_ws = Variable(rois_inside_ws.view(-1, rois_inside_ws.size(2)))
                    rois_outside_ws = Variable(rois_outside_ws.view(-1, rois_outside_ws.size(2)))
                else:
                    rois_label = None
                    rois_target = None
                    rois_inside_ws = None
                    rois_outside_ws = None
                    rpn_loss_cls = 0
                    rpn_loss_bbox = 0
                rois = Variable(rois)

                if cfg.POOLING_MODE == 'align':
                    pooled_feat_di = self.RCNN_roi_align(base_feat_di, rois.view(-1, 5))
                    pooled_feat = self.RCNN_roi_align(base_feat, rois.detach().view(-1, 5))
                    pooled_feat_ds = self.RCNN_roi_align(base_feat_ds, rois.detach().view(-1, 5))

                pooled_feat_ds_mean = pooled_feat_ds
                cat_reps = torch.cat((pooled_feat_di, pooled_feat_ds_mean), 1)
                pooled_mean = self.recon(cat_reps)
                recon_loss = self.reconstruct_loss(pooled_mean, pooled_feat.detach())

                return recon_loss

    def _init_weights(self):
        def normal_init(m, mean, stddev, truncated=False):
            """
            weight initalizer: truncated normal and random normal.
            """
            # x is a parameter
            if truncated:
                m.weight.data.normal_().fmod_(2).mul_(stddev).add_(mean) # not a perfect approximation
            else:
                m.weight.data.normal_(mean, stddev)
                m.bias.data.zero_()

        normal_init(self.RCNN_rpn.RPN_Conv, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_rpn.RPN_cls_score, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_rpn.RPN_bbox_pred, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_cls_score_di, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_bbox_pred_di, 0, 0.001, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_cls_score_base, 0, 0.01, cfg.TRAIN.TRUNCATED)
        normal_init(self.RCNN_bbox_pred_base, 0, 0.001, cfg.TRAIN.TRUNCATED)

    def create_architecture(self):
        self._init_modules()
        self._init_weights()
